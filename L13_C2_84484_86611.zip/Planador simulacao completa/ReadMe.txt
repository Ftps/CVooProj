Correr as primeiras 4 linhas do ficheiro run_all para inicializar a simula��o
As outras linhas fazem o plot 3D do percurso depois de correr a simula��o no Simulink

Os ficheiros modelo_L13_PD_lateral e real_servo_c_lateral correspondem �s simula��es em anel fechado do controlador PD e LQR, antes de juntar ao longitudinal, para correr o Servomecanismo_LQR_lateral