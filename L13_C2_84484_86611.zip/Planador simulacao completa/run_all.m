lateral_ctes
long_ctes
coordenadas2
Modelo_NL_Final

% plot3(pontos_T(1,:),pontos_T(2,:),zeros(2,8),'b')
% hold on
% plot3(out.enu(:,1),out.enu(:,2),out.enu(:,3),'r')
% axis equal
% 
% plot(pontos_T(1,:),pontos_T(2,:),'b')
% hold on
% plot(out.enu(:,1),out.enu(:,2),'r')
% plot(pontos_T(1,7:8),pontos_T(2,7:8),'o') % marca a pista
% axis equal
% 
% th = 0:pi/50:2*pi;
% xunit = 200 * cos(th) + pontos(2,1);
% yunit = 200 * sin(th) + pontos(2,2);
% plot(xunit, yunit,'g');
% xunit = 200 * cos(th) + pontos(3,1);
% yunit = 200 * sin(th) + pontos(3,2);
% plot(xunit, yunit,'g');